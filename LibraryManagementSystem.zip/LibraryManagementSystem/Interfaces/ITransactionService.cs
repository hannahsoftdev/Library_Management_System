// ----------------------------------------------------------------------------------------
// File: ITransactionService.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------

using System.Collections.Generic;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Interfaces
{
    public interface ITransactionService
    {
        List<Transaction> GetAllTransactions();
        Transaction GetTransactionById(int id);
        void AddTransaction(Transaction transaction);
        void UpdateTransaction(Transaction transaction);
        void DeleteTransaction(int id);
    }
}