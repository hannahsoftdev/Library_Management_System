// ----------------------------------------------------------------------------------------
// File: IMemberService.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------

using System.Collections.Generic;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Interfaces
{
    public interface IMemberService
    {
        List<Member> GetAllMembers();
        Member GetMemberById(int id);
        void AddMember(Member member);
        void UpdateMember(Member member);
        void DeleteMember(int id);
    }
}