// ----------------------------------------------------------------------------------------
// File: TransactionService.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Interfaces;
using LibraryManagementSystem.DataAccess;
using Microsoft.Data.Sqlite;

namespace LibraryManagementSystem.Services
{
    public class TransactionService : ITransactionService
    {
        public List<Transaction> GetAllTransactions()
        {
            List<Transaction> transactions = new List<Transaction>();

            try
            {
                using var connection = AppDbContext.GetConnection();
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM Transactions";

                using var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    transactions.Add(new Transaction
                    {
                        TransactionID = reader.GetInt32(0),
                        BookID = reader.GetInt32(1),
                        MemberID = reader.GetInt32(2),
                        IssueDate = DateTime.Parse(reader.GetString(3)),
                        DueDate = DateTime.Parse(reader.GetString(4)),
                        ReturnDate = reader.IsDBNull(5) ? null : DateTime.Parse(reader.GetString(5))
                    });
                }
            }
            catch (Exception ex)
        {
            throw;
        }

            return transactions;
        }

        public Transaction GetTransactionById(int id)
        {
            try
            {
                using var connection = AppDbContext.GetConnection();
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM Transactions WHERE TransactionID = $id";
                command.Parameters.AddWithValue("$id", id);

                using var reader = command.ExecuteReader();
                if (reader.Read())
                {
                    return new Transaction
                    {
                        TransactionID = reader.GetInt32(0),
                        BookID = reader.GetInt32(1),
                        MemberID = reader.GetInt32(2),
                        IssueDate = DateTime.Parse(reader.GetString(3)),
                        DueDate = DateTime.Parse(reader.GetString(4)),
                        ReturnDate = reader.IsDBNull(5) ? null : DateTime.Parse(reader.GetString(5))
                    };
                }
            }
            catch (Exception ex)
        {
            throw;
        }

            return null;
        }

        public void AddTransaction(Transaction transaction)
        {
            try
            {
                using var connection = AppDbContext.GetConnection();
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                    INSERT INTO Transactions (BookID, MemberID, IssueDate, DueDate, ReturnDate) 
                    VALUES ($bookID, $memberID, $issueDate, $dueDate, $returnDate)";
                command.Parameters.AddWithValue("$bookID", transaction.BookID);
                command.Parameters.AddWithValue("$memberID", transaction.MemberID);
                command.Parameters.AddWithValue("$issueDate", transaction.IssueDate.ToString("yyyy-MM-dd"));
                command.Parameters.AddWithValue("$dueDate", transaction.DueDate.ToString("yyyy-MM-dd"));
                command.Parameters.AddWithValue("$returnDate", transaction.ReturnDate?.ToString("yyyy-MM-dd"));
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
        {
            throw;
        }
        }

        public void UpdateTransaction(Transaction transaction)
        {
            try
            {
                using var connection = AppDbContext.GetConnection();
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                    UPDATE Transactions SET 
                        BookID = $bookID,
                        MemberID = $memberID,
                        IssueDate = $issueDate,
                        DueDate = $dueDate,
                        ReturnDate = $returnDate
                    WHERE TransactionID = $id";
                command.Parameters.AddWithValue("$bookID", transaction.BookID);
                command.Parameters.AddWithValue("$memberID", transaction.MemberID);
                command.Parameters.AddWithValue("$issueDate", transaction.IssueDate.ToString("yyyy-MM-dd"));
                command.Parameters.AddWithValue("$dueDate", transaction.DueDate.ToString("yyyy-MM-dd"));
                command.Parameters.AddWithValue("$returnDate", transaction.ReturnDate?.ToString("yyyy-MM-dd"));
                command.Parameters.AddWithValue("$id", transaction.TransactionID);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
        {
            throw;
        }
        }

        public void DeleteTransaction(int id)
        {
            try
            {
                using var connection = AppDbContext.GetConnection();
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "DELETE FROM Transactions WHERE TransactionID = $id";
                command.Parameters.AddWithValue("$id", id);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
        {
            throw;
        }
        }
    }
}