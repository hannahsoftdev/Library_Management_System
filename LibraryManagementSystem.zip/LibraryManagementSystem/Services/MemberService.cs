// ----------------------------------------------------------------------------------------
// File: MemberService.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Interfaces;
using LibraryManagementSystem.DataAccess;
using Microsoft.Data.Sqlite;

namespace LibraryManagementSystem.Services
{
    public class MemberService : IMemberService
    {
        public List<Member> GetAllMembers()
        {
            var list = new List<Member>();
            using var conn = AppDbContext.GetConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                SELECT MemberId, Name, Email, Phone, MemberType, Program, Department
                FROM Members";
            using var rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                var type = rdr.GetString(rdr.GetOrdinal("MemberType"));
                Member m = type == "Student"
                    ? new Student { Program = rdr.GetString(rdr.GetOrdinal("Program")) }
                    : (Member)new Staff  { Department = rdr.GetString(rdr.GetOrdinal("Department")) };

                m.MemberId   = rdr.GetInt32(rdr.GetOrdinal("MemberId"));
                m.Name       = rdr.GetString(rdr.GetOrdinal("Name"));
                m.Email      = rdr.GetString(rdr.GetOrdinal("Email"));
                m.Phone      = rdr.GetString(rdr.GetOrdinal("Phone"));
                m.MemberType = type;
                list.Add(m);
            }
            return list;
        }

        public void AddMember(Member m)
        {
            using var conn = AppDbContext.GetConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                INSERT INTO Members (Name, Email, Phone, MemberType, Program, Department)
                VALUES (@name, @email, @phone, @type, @prog, @dept)";
            cmd.Parameters.AddWithValue("@name",  m.Name);
            cmd.Parameters.AddWithValue("@mail",  m.Email);
            cmd.Parameters.AddWithValue("@phone", m.Phone);
            cmd.Parameters.AddWithValue("@type",  m.MemberType);
            cmd.Parameters.AddWithValue("@prog",  m is Student s ? s.Program : (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@dept",  m is Staff  s ? s.Department : (object)DBNull.Value);
            cmd.ExecuteNonQuery();
        }

        public void UpdateMember(Member m)
        {
            using var conn = AppDbContext.GetConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
                UPDATE Members
                SET Name=@name, Email=@email, Phone=@phone,
                    MemberType=@type, Program=@prog, Department=@dept
                WHERE MemberId=@id";
            cmd.Parameters.AddWithValue("@name",  m.Name);
            cmd.Parameters.AddWithValue("@mail",  m.Email);
            cmd.Parameters.AddWithValue("@phone", m.Phone);
            cmd.Parameters.AddWithValue("@type",  m.MemberType);
            cmd.Parameters.AddWithValue("@prog",  m is Student s ? s.Program : (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@dept",  m is Staff  s ? s.Department : (object)DBNull.Value);
            cmd.Parameters.AddWithValue("@id",    m.MemberId);
            cmd.ExecuteNonQuery();
        }

        public void DeleteMember(int id)
        {
            using var conn = AppDbContext.GetConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "DELETE FROM Members WHERE MemberId=@id";
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }
    }
}
