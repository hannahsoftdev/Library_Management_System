// ----------------------------------------------------------------------------------------
// File: BookService.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Interfaces;
using LibraryManagementSystem.DataAccess;
using Microsoft.Data.Sqlite;

namespace LibraryManagementSystem.Services
{
    public class BookService : IBookService
    {
        public List<Book> GetAllBooks()
        {
            List<Book> books = new List<Book>();

            try
            {
                using var connection = AppDbContext.GetConnection();
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM Books";

                using var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    books.Add(new Book
                    {
                        BookID = reader.GetInt32(0),
                        Title = reader.GetString(1),
                        Author = reader.GetString(2),
                        Genre = reader.GetString(3),
                        IsAvailable = reader.GetBoolean(4)
                    });
                }
            }
            catch (Exception ex)
        {
            throw;
        }

            return books;
        }

        public Book GetBookById(int id)
        {
            try
            {
                using var connection = AppDbContext.GetConnection();
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM Books WHERE BookID = $id";
                command.Parameters.AddWithValue("$id", id);

                using var reader = command.ExecuteReader();
                if (reader.Read())
                {
                    return new Book
                    {
                        BookID = reader.GetInt32(0),
                        Title = reader.GetString(1),
                        Author = reader.GetString(2),
                        Genre = reader.GetString(3),
                        IsAvailable = reader.GetBoolean(4)
                    };
                }
            }
            catch (Exception ex)
        {
            throw;
        }

            return null;
        }

        public void AddBook(Book book)
        {
            try
            {
                using var connection = AppDbContext.GetConnection();
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                    INSERT INTO Books (Title, Author, Genre, IsAvailable) 
                    VALUES ($title, $author, $genre, $available)";
                command.Parameters.AddWithValue("$title", book.Title);
                command.Parameters.AddWithValue("$author", book.Author);
                command.Parameters.AddWithValue("$genre", book.Genre);
                command.Parameters.AddWithValue("$available", book.IsAvailable);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
        {
            throw;
        }
        }

        public void UpdateBook(Book book)
        {
            try
            {
                using var connection = AppDbContext.GetConnection();
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                    UPDATE Books SET 
                        Title = $title, 
                        Author = $author, 
                        Genre = $genre, 
                        IsAvailable = $available 
                    WHERE BookID = $id";
                command.Parameters.AddWithValue("$title", book.Title);
                command.Parameters.AddWithValue("$author", book.Author);
                command.Parameters.AddWithValue("$genre", book.Genre);
                command.Parameters.AddWithValue("$available", book.IsAvailable);
                command.Parameters.AddWithValue("$id", book.BookID);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
        {
            throw;
        }
        }

        public void DeleteBook(int id)
        {
            try
            {
                using var connection = AppDbContext.GetConnection();
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "DELETE FROM Books WHERE BookID = $id";
                command.Parameters.AddWithValue("$id", id);
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
        {
            throw;
        }
        }
    }
}