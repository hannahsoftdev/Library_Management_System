// ----------------------------------------------------------------------------------------
// File: App.xaml.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------
using Microsoft.Maui.Controls;

namespace LibraryManagementSystem
{
/// <summary>
/// Application entry point and resource initialization.
/// </summary>
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }
    }
}
