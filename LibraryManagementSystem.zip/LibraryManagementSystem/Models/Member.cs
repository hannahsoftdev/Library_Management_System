// ----------------------------------------------------------------------------------------
// File: Member.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------

// File: Models/Member.cs
namespace LibraryManagementSystem.Models
{
    public abstract class Member
    {
        public int    MemberId   { get; set; }
        public string Name       { get; set; }
        public string Email      { get; set; }
        public string Phone      { get; set; }
        public string MemberType { get; set; }
        public abstract string DisplayInfo();
    }
}
