// ----------------------------------------------------------------------------------------
// File: Book.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------

namespace LibraryManagementSystem.Models
{
    public class Book
    {
        public int BookID { get; set; } // Primary key
        public string Title { get; set; }
        public string Author { get; set; }
        public string Genre { get; set; }
        public bool IsAvailable { get; set; } = true;
    }
}