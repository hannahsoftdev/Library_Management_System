// ----------------------------------------------------------------------------------------
// File: Staff.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------

// File: Models/Staff.cs
using System;
namespace LibraryManagementSystem.Models
{
    public class Staff : Member
    {
        public string Department { get; set; }
        public override string DisplayInfo() =>
            $"{Name} (Staff) — Dept: {Department}";
    }
}
