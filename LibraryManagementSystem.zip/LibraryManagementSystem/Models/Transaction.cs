// ----------------------------------------------------------------------------------------
// File: Transaction.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------

using System;

namespace LibraryManagementSystem.Models
{
    public class Transaction
    {
        public int TransactionID { get; set; } // Primary key
        public int BookID { get; set; }        // Foreign key
        public int MemberID { get; set; }      // Foreign key
        public DateTime IssueDate { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime? ReturnDate { get; set; } // Nullable
    }
}