// ----------------------------------------------------------------------------------------
// File: Student.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------

// File: Models/Student.cs
using System;
namespace LibraryManagementSystem.Models
{
    public class Student : Member
    {
        public string Program { get; set; }
        public override string DisplayInfo() =>
            $"{Name} (Student) — Program: {Program}";
    }
}
