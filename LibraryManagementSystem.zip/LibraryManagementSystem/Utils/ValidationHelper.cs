// ----------------------------------------------------------------------------------------
// File: ValidationHelper.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------
using System;
using System.Text.RegularExpressions;

namespace LibraryManagementSystem.Utils
{
    public static class ValidationHelper
    {
        private static readonly Regex _emailRx =
            new(@"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.Compiled);
        private static readonly Regex _phoneRx =
            new(@"^\+?\d{7,15}$", RegexOptions.Compiled);

        public static bool IsValidEmail(string email) =>
            !string.IsNullOrWhiteSpace(email) && _emailRx.IsMatch(email);

        public static bool IsValidPhone(string phone) =>
            !string.IsNullOrWhiteSpace(phone) && _phoneRx.IsMatch(phone);

        public static bool IsDateOrderValid(DateTime issue, DateTime due) =>
            due > issue;
    }
}
