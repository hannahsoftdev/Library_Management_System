// ----------------------------------------------------------------------------------------
// File: UIValidationAndExceptions.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------

// Sample code: Input validation and exception handling (BooksPage.xaml.cs)

private void AddBook(string title, string author, string genre)
{
    if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(author))
    {
        DisplayAlert("Validation Error", "Title and Author fields cannot be empty.", "OK");
        return;
    }

    try
    {
        Book newBook = new Book
        {
            Title = title,
            Author = author,
            Genre = genre,
            IsAvailable = true
        };

        var bookService = new BookService();
        bookService.AddBook(newBook);

        DisplayAlert("Success", "Book added successfully!", "OK");
    }
    catch (Exception ex)
    {
        DisplayAlert("Error", "Failed to add book. " + ex.Message, "OK");
    }
}