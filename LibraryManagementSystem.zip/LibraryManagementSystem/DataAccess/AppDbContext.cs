// ----------------------------------------------------------------------------------------
// File: AppDbContext.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------

using Microsoft.Data.Sqlite;
using Microsoft.Maui.Storage;
using System;
using System.IO;

namespace LibraryManagementSystem.DataAccess
{
    public static class AppDbContext
    {
        private const string DbFileName = "LibraryDB.db";
        public static string DbPath => Path.Combine(FileSystem.AppDataDirectory, DbFileName);

        public static SqliteConnection GetConnection() =>
            new SqliteConnection($"Data Source={DbPath}");

        public static void InitializeDatabase()
        {
            using var conn = GetConnection();
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = @"
            CREATE TABLE IF NOT EXISTS Members (
                MemberId    INTEGER PRIMARY KEY AUTOINCREMENT,
                Name        TEXT    NOT NULL,
                Email       TEXT,
                Phone       TEXT,
                MemberType  TEXT    NOT NULL,
                Program     TEXT,
                Department  TEXT
            );
            CREATE TABLE IF NOT EXISTS Books (
                BookId      INTEGER PRIMARY KEY AUTOINCREMENT,
                Title       TEXT    NOT NULL,
                Author      TEXT,
                Genre       TEXT,
                IsAvailable INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS Transactions (
                TransactionId INTEGER PRIMARY KEY AUTOINCREMENT,
                MemberId      INTEGER NOT NULL,
                BookId        INTEGER NOT NULL,
                IssueDate     TEXT    NOT NULL,
                DueDate       TEXT,
                ReturnDate    TEXT,
                FOREIGN KEY(MemberId) REFERENCES Members(MemberId),
                FOREIGN KEY(BookId)   REFERENCES Books(BookId)
            );";
            cmd.ExecuteNonQuery();
        }
    }
}
