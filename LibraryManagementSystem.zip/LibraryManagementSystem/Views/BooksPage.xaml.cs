// ----------------------------------------------------------------------------------------
// File: BooksPage.xaml.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------
using System;
using System.Linq;
using Microsoft.Maui.Controls;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Services;

namespace LibraryManagementSystem.Views
{
    public partial class BooksPage : ContentPage
    {
        private readonly BookService _service = new BookService();

/// <summary>
/// Initializes the Books page and loads existing books.
/// </summary>
        public BooksPage()
        {
            InitializeComponent();
            AppDbContext.InitializeDatabase();
            LoadBooks();
        }

/// <summary>
/// Filters books based on title or author search input.
/// </summary>
        private void OnSearchTextChanged(object sender, TextChangedEventArgs e)
        {
            var query = e.NewTextValue;
            var books = _service.GetAllBooks();
            if (!string.IsNullOrWhiteSpace(query))
                books = books.Where(b => b.Title.Contains(query, StringComparison.OrdinalIgnoreCase)
                                      || b.Author.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList();
            BooksCollection.ItemsSource = books;
        }

/// <summary>
/// Filters books by selected genre.
/// </summary>
        private void OnFilterChanged(object sender, EventArgs e)
        {
            var genre = GenrePicker.SelectedItem?.ToString();
            var books = string.IsNullOrWhiteSpace(genre)
                ? _service.GetAllBooks()
                : _service.GetAllBooks().Where(b => b.Genre == genre).ToList();
            BooksCollection.ItemsSource = books;
        }

/// <summary>
/// Validates input and adds a new book to the database.
/// </summary>
        private void OnAddBookClicked(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TitleEntry.Text) || string.IsNullOrWhiteSpace(AuthorEntry.Text))
            {
                DisplayAlert("Validation Error", "Title and Author are required.", "OK");
                return;
            }
            var book = new Book
            {
                Title = TitleEntry.Text,
                Author = AuthorEntry.Text,
                Genre = GenreEntry.Text,
                IsAvailable = AvailabilitySwitch.IsToggled
            };
            try
            {
                _service.AddBook(book);
                LoadBooks();
                DisplayAlert("Success", "Book added.", "OK");
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

/// <summary>
/// Populates detail fields when a book is selected.
/// </summary>
        private void OnBookSelected(object sender, SelectionChangedEventArgs e)
        {
            var selected = e.CurrentSelection.FirstOrDefault() as Book;
            if (selected == null) return;
            TitleEntry.Text        = selected.Title;
            AuthorEntry.Text       = selected.Author;
            GenreEntry.Text        = selected.Genre;
            AvailabilitySwitch.IsToggled = selected.IsAvailable;
        }

        private void LoadBooks()
        {
            BooksCollection.ItemsSource = _service.GetAllBooks();
        }

        private void OnAvailableClicked(object sender, EventArgs e)
        {
            BooksCollection.ItemsSource = _service.GetAllBooks().Where(b => b.IsAvailable);
        }

        private void OnCheckedOutClicked(object sender, EventArgs e)
        {
            BooksCollection.ItemsSource = _service.GetAllBooks().Where(b => !b.IsAvailable);
        }
    }
}
