// ----------------------------------------------------------------------------------------
// File: MembersPage.xaml.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------
using System;
using System.Linq;
using Microsoft.Maui.Controls;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Services;
using LibraryManagementSystem.Utils;

namespace LibraryManagementSystem.Views
{
    public partial class MembersPage : ContentPage
    {
        private readonly MemberService _service = new MemberService();

/// <summary>
/// Initializes the Members page and loads existing members.
/// </summary>
        public MembersPage()
        {
            InitializeComponent();
            AppDbContext.InitializeDatabase();
            LoadMembers();
        }

/// <summary>
/// Filters the members list based on the search query.
/// </summary>
        private void OnSearchTextChanged(object sender, TextChangedEventArgs e)
        {
            var query = e.NewTextValue;
            var members = _service.GetAllMembers();
            if (!string.IsNullOrWhiteSpace(query))
                members = members.Where(m => m.Name.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList();
            MembersCollection.ItemsSource = members;
        }

/// <summary>
/// Toggles visibility of Program/Department entries based on member type.
/// </summary>
        private void TypePicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            ProgramEntry.IsVisible = TypePicker.SelectedItem?.ToString() == "Student";
            DeptEntry.IsVisible    = TypePicker.SelectedItem?.ToString() == "Staff";
        }

/// <summary>
/// Validates input and adds a new member to the database.
/// </summary>
/// <param name="sender">Event sender.</param>
/// <param name="e">Event arguments.</param>
        private void OnAddMemberClicked(object sender, EventArgs e)
        {
            // Ensure member type is selected
            if (TypePicker.SelectedIndex < 0)
            {
                DisplayAlert("Validation Error", "Please select member type.", "OK");
                return;
            }
            if (!ValidationHelper.IsValidEmail(EmailEntry.Text) || !ValidationHelper.IsValidPhone(PhoneEntry.Text))
            {
                DisplayAlert("Validation Error", "Please enter valid email and phone.", "OK");
                return;
            }

            Member m = TypePicker.SelectedItem.ToString() == "Student"
                ? new Student { Program = ProgramEntry.Text }
                : new Staff   { Department = DeptEntry.Text };

            m.Name  = NameEntry.Text;
            m.Email = EmailEntry.Text;
            m.Phone = PhoneEntry.Text;
            m.MemberType = TypePicker.SelectedItem.ToString();

            try
            {
                _service.AddMember(m);
                LoadMembers();
                DisplayAlert("Success", "Member added.", "OK");
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

/// <summary>
/// Populates detail form fields when a member is selected.
/// </summary>
        private void OnMemberSelected(object sender, SelectionChangedEventArgs e)
        {
            var selected = e.CurrentSelection.FirstOrDefault() as Member;
            if (selected == null) return;
            NameEntry.Text    = selected.Name;
            EmailEntry.Text   = selected.Email;
            PhoneEntry.Text   = selected.Phone;
            TypePicker.SelectedItem = selected.MemberType;
            if (selected is Student s) ProgramEntry.Text = s.Program;
            if (selected is Staff   s2) DeptEntry.Text    = s2.Department;
        }

        private void LoadMembers()
        {
            MembersCollection.ItemsSource = _service.GetAllMembers();
        }
    }
}
