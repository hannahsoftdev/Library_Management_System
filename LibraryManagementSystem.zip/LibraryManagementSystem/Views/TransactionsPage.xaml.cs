// ----------------------------------------------------------------------------------------
// File: TransactionsPage.xaml.cs
// Author: Hannah Mae Tolentino
// Student ID: 000953335
// Course: CPRG-211-E
// Date: April 2025
// ----------------------------------------------------------------------------------------
using System;
using System.Linq;
using Microsoft.Maui.Controls;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Services;

namespace LibraryManagementSystem.Views
{
    public partial class TransactionsPage : ContentPage
    {
        private readonly TransactionService _txnService = new TransactionService();
        private readonly MemberService _memberService = new MemberService();
        private readonly BookService _bookService = new BookService();

/// <summary>
/// Initializes the Transactions page and loads existing transactions.
/// </summary>
        public TransactionsPage()
        {
            InitializeComponent();
            AppDbContext.InitializeDatabase();
            MemberPicker.ItemsSource = _memberService.GetAllMembers();
            BookPicker.ItemsSource   = _bookService.GetAllBooks();
            LoadTransactions();
        }

/// <summary>
/// Issues a book to a selected member after validation.
/// </summary>
        private void OnIssueClicked(object sender, EventArgs e)
        {
            // Validate due date order
            if (!LibraryManagementSystem.Utils.ValidationHelper.IsDateOrderValid(txn.IssueDate, txn.DueDate))
            {
                DisplayAlert("Validation Error", "Due date must be after issue date.", "OK");
                return;
            }
            var member = MemberPicker.SelectedItem as Member;
            var book   = BookPicker.SelectedItem   as Book;
            if (member == null || book == null)
            {
                DisplayAlert("Validation Error", "Select member and book.", "OK");
                return;
            }
            if (!book.IsAvailable)
            {
                DisplayAlert("Error", "Book not available.", "OK");
                return;
            }
            var txn = new Transaction
            {
                MemberID = member.MemberId,
                BookID   = book.BookID,
                IssueDate = DateTime.Now,
                DueDate   = DateTime.Now.AddDays(14)
            };
            try
            {
                _txnService.AddTransaction(txn);
                book.IsAvailable = false;
                _bookService.UpdateBook(book);
                LoadTransactions();
                DisplayAlert("Success", "Book issued.", "OK");
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

/// <summary>
/// Returns a book and updates the transaction record.
/// </summary>
        private void OnReturnClicked(object sender, EventArgs e)
        {
            var member = MemberPicker.SelectedItem as Member;
            var book   = BookPicker.SelectedItem   as Book;
            var txn = _txnService.GetAllTransactions()
                .LastOrDefault(t => t.MemberID == member.MemberId && t.BookID == book.BookID && t.ReturnDate == null);
            if (txn == null)
            {
                DisplayAlert("Error", "No active transaction.", "OK");
                return;
            }
            try
            {
                txn.ReturnDate = DateTime.Now;
                _txnService.UpdateTransaction(txn);
                book.IsAvailable = true;
                _bookService.UpdateBook(book);
                LoadTransactions();
                DisplayAlert("Success", "Book returned.", "OK");
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", ex.Message, "OK");
            }
        }

/// <summary>
/// Loads all transactions into the collection view.
/// </summary>
        private void LoadTransactions()
        {
            TransactionsCollection.ItemsSource = _txnService.GetAllTransactions();
        }

        private void OnActiveClicked(object sender, EventArgs e)
        {
            TransactionsCollection.ItemsSource = _txnService.GetAllTransactions()
                .Where(t => t.ReturnDate == null);
        }

        private void OnOverdueClicked(object sender, EventArgs e)
        {
            TransactionsCollection.ItemsSource = _txnService.GetAllTransactions()
                .Where(t => t.DueDate < DateTime.Now && t.ReturnDate == null);
        }
    }
}
